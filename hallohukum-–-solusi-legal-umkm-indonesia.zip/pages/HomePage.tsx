import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import Hero from '../components/Hero';
import Services from '../components/Services';
import Testimonials from '../components/Testimonials';
import Pricing from '../components/Pricing';
import Icon from '../components/Icon';

interface FaqItemProps {
  question: string;
  answer: string;
}

const FaqItem: React.FC<FaqItemProps> = ({ question, answer }) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="border-b border-slate-200 py-6">
      <button
        className="w-full flex justify-between items-center text-left text-lg font-semibold text-brand-dark"
        onClick={() => setIsOpen(!isOpen)}
        aria-expanded={isOpen}
      >
        <span>{question}</span>
        <Icon className={`w-5 h-5 transition-transform duration-300 ${isOpen ? 'transform rotate-180' : ''}`}>
            <polyline points="6 9 12 15 18 9"></polyline>
        </Icon>
      </button>
      <div
        className={`overflow-hidden transition-all duration-300 ease-in-out ${
          isOpen ? 'max-h-screen mt-4' : 'max-h-0'
        }`}
      >
        <p className="text-slate-600 pr-8">{answer}</p>
      </div>
    </div>
  );
};

const HomePage: React.FC = () => {
  const openHumiChat = () => {
    window.dispatchEvent(new CustomEvent('openHumiChat'));
  };

  const scheduleVideoCall = () => {
    window.dispatchEvent(new CustomEvent('scheduleVideoCall'));
  };

  const faqs = [
    {
      question: "Apa saja layanan utama yang ditawarkan HalloHukum?",
      answer: "HalloHukum menyediakan layanan legalitas usaha (pendirian PT, CV, UMKM), pembuatan berbagai jenis kontrak bisnis, pendaftaran kekayaan intelektual, dan konsultasi langsung dengan ahli hukum."
    },
    {
      question: "Apakah konsultasi dengan HUMI AI berbayar?",
      answer: "Tidak. Konsultasi awal dengan AI Legal Agent kami, HUMI, adalah gratis. HUMI dapat memberikan informasi dan panduan umum. Untuk nasihat hukum yang lebih spesifik, kami akan merekomendasikan Anda untuk terhubung dengan konsultan hukum manusia kami."
    },
    {
      question: "Bagaimana proses pendirian PT melalui HalloHukum?",
      answer: "Prosesnya sangat mudah. Anda hanya perlu mengisi formulir online, mengunggah dokumen yang diperlukan, dan tim kami akan menangani semua proses birokrasi dari awal hingga akhir hingga badan usaha Anda resmi terdaftar."
    },
    {
      question: "Berapa lama waktu yang dibutuhkan untuk mendaftarkan merek dagang?",
      answer: "Proses pendaftaran merek dagang hingga terbitnya sertifikat bisa memakan waktu antara 12 hingga 24 bulan. Namun, perlindungan hukum dimulai sejak tanggal permohonan Anda diterima oleh DJKI."
    }
  ];

  return (
    <>
      <Hero />
      <Services />

      {/* Humi Call to Action Section */}
      <section className="bg-brand-dark">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-20 sm:py-24">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="text-center lg:text-left">
              <h2 className="text-3xl sm:text-4xl font-extrabold text-white">
                Punya Pertanyaan Hukum? <span className="text-brand-secondary">Tanya HUMI</span>
              </h2>
              <p className="mt-4 max-w-xl mx-auto lg:mx-0 text-lg text-slate-300">
                AI Legal Agent kami siap 24/7 untuk memberikan informasi awal dan panduan mengenai kebutuhan legalitas bisnis Anda. Cepat, mudah, dan gratis.
              </p>
              <button
                onClick={openHumiChat}
                className="mt-8 inline-flex items-center justify-center gap-3 rounded-lg text-base font-semibold py-3 px-6 bg-brand-accent text-brand-dark hover:bg-amber-300 transition-all shadow-lg hover:shadow-xl transform hover:-translate-y-0.5"
                aria-label="Mulai Chat dengan HUMI"
              >
                <Icon className="w-5 h-5">
                  <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
                </Icon>
                Mulai Chat Sekarang
              </button>
            </div>
            <div className="flex justify-center lg:justify-end">
              <img 
                src="https://images.unsplash.com/photo-1551288049-bebda4e38f71?q=80&w=1200&auto=format&fit=crop" 
                alt="Ilustrasi antarmuka AI Legal Agent" 
                className="rounded-2xl shadow-2xl object-cover max-w-md w-full"
                style={{aspectRatio: '4/3'}}
              />
            </div>
          </div>
        </div>
      </section>

      <Testimonials />

      {/* Video Consultation CTA Section */}
      <section className="py-20 sm:py-24 bg-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mx-auto text-center bg-brand-light p-8 sm:p-12 rounded-2xl shadow-lg border border-slate-200">
            <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-brand-secondary text-white mb-6">
                <Icon className="h-8 w-8">
                    <path d="M15.5 3H8.5a1 1 0 0 0-1 1v1.5a1 1 0 0 0 1 1h7a1 1 0 0 0 1-1V4a1 1 0 0 0-1-1z"></path>
                    <path d="M2 12h20"></path>
                    <path d="M2 7h20v10a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2z"></path>
                </Icon>
            </div>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-brand-dark">Siap Mengambil Langkah Berikutnya?</h2>
            <p className="mt-4 text-slate-600 max-w-xl mx-auto">
              Diskusikan kebutuhan hukum bisnis Anda secara langsung dengan konsultan berpengalaman kami. Jadwalkan sesi konsultasi video gratis sekarang juga.
            </p>
            <div className="mt-8">
              <button
                onClick={scheduleVideoCall}
                className="inline-flex items-center justify-center gap-2 rounded-lg text-base font-semibold py-3 px-8 bg-brand-accent text-brand-dark hover:bg-amber-300 transition-all shadow-lg hover:shadow-xl transform hover:-translate-y-0.5"
                aria-label="Jadwalkan Konsultasi Video Gratis"
              >
                Jadwalkan Konsultasi Video Gratis
              </button>
            </div>
          </div>
        </div>
      </section>

      <section id="faq" className="py-20 sm:py-28">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-extrabold text-brand-dark">Pertanyaan Umum</h2>
            <p className="mt-4 max-w-2xl mx-auto text-lg text-slate-600">
              Temukan jawaban cepat untuk pertanyaan-pertanyaan yang paling sering diajukan.
            </p>
          </div>
          <div className="max-w-3xl mx-auto">
            {faqs.map((faq, index) => (
                <FaqItem key={index} question={faq.question} answer={faq.answer} />
            ))}
          </div>
           <div className="text-center mt-12">
                <Link to="/faq" className="font-semibold text-brand-secondary hover:text-sky-400 transition-colors">
                    Lihat Semua Pertanyaan &rarr;
                </Link>
            </div>
        </div>
      </section>

      <Pricing />
    </>
  );
};

export default HomePage;