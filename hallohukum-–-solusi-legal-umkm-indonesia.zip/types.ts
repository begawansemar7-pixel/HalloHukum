import React from 'react';

export interface User {
  id: string;
  name: string;
  email: string;
  isEmailVerified: boolean;
  phone?: string;
  profilePicture?: string; // Will store base64 string
}

export interface ChatMessage {
  id: number;
  text: string;
  sender: 'user' | 'ai';
}

export interface RelatedContentItem {
  type: 'blog' | 'faq';
  title: string;
  description: string;
  link?: string;
}

export interface Benefit {
  icon: React.ReactElement;
  title: string;
  description: string;
}

export interface ServiceOption {
  slug: string;
  title: string;
  description: string;
  features: string[];
  bestFor: string;
  isPopular?: boolean;
  detailedContent: {
    longDescription: string;
    useCases: { title: string; description: string }[];
    requirements: string[];
  };
}