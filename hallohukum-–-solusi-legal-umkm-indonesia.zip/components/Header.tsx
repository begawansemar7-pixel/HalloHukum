import React, { useState, useRef, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import Icon from './Icon';
import { useAuth } from '../contexts/AuthContext';

const Header: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);
  const [showVerificationBanner, setShowVerificationBanner] = useState(true);
  const [isResending, setIsResending] = useState(false);
  const userMenuRef = useRef<HTMLDivElement>(null);
  const { isAuthenticated, user, logout, resendVerificationEmail } = useAuth();
  const navigate = useNavigate();

  const navItems = [
    { name: 'About Us', path: '/about-us' },
    { name: 'Layanan', path: '/layanan' },
    { name: 'Harga', path: '/harga' },
    { name: 'Blog', path: '/blog' },
    { name: 'FAQ', path: '/faq' },
    { name: 'Hubungi Kami', path: '/kontak' },
  ];

  const primaryNavItem = { name: 'Mulai Sekarang', path: '/mulai' };

  const handleRequestCallback = () => {
    window.dispatchEvent(new CustomEvent('requestCallback'));
    setIsMenuOpen(false);
  };
  
  const handleLogout = () => {
    logout();
    setIsUserMenuOpen(false);
    navigate('/');
  };

  const handleResendEmail = async () => {
    setIsResending(true);
    try {
      await resendVerificationEmail();
      // Optionally show a success message
    } catch (error) {
      console.error("Failed to resend verification email:", error);
      // Optionally show an error message
    } finally {
      setTimeout(() => setIsResending(false), 1000);
    }
  };

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (userMenuRef.current && !userMenuRef.current.contains(event.target as Node)) {
        setIsUserMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);


  return (
    <header className="bg-brand-light/80 backdrop-blur-md sticky top-0 z-40 w-full">
       {isAuthenticated && user && !user.isEmailVerified && showVerificationBanner && (
        <div className="bg-amber-100 border-b-2 border-amber-300 text-amber-800 px-4 py-2">
          <div className="container mx-auto flex items-center justify-between text-sm">
            <p>
              <span className="font-bold">Verifikasi Diperlukan:</span> Akun Anda belum diverifikasi. Silakan periksa email Anda.
            </p>
            <div className="flex items-center gap-4">
               <button
                  onClick={handleResendEmail}
                  disabled={isResending}
                  className="font-semibold hover:underline disabled:opacity-50 disabled:cursor-wait"
                >
                  {isResending ? 'Mengirim...' : 'Kirim Ulang'}
                </button>
              <button onClick={() => setShowVerificationBanner(false)} aria-label="Tutup notifikasi verifikasi">
                 <Icon className="w-5 h-5"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></Icon>
              </button>
            </div>
          </div>
        </div>
      )}
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 border-b border-slate-200">
        <div className="flex items-center justify-between h-20">
          <Link to="/" onClick={() => setIsMenuOpen(false)} className="flex items-center space-x-2" aria-label="HalloHukum Homepage">
             <div className="bg-brand-dark p-2 rounded-lg">
                <Icon className="text-brand-accent">
                    <path d="M12 22V2M2 12H22M17 2H7L2 12L7 22H17L22 12L17 2Z" />
                    <path d="M2.5 12C2.5 17.5228 7.47715 22.5 13 22.5" />
                    <path d="M21.5 12C21.5 6.47715 16.5228 1.5 11 1.5" />
                </Icon>
             </div>
            <span className="text-2xl font-bold text-brand-dark">HalloHukum</span>
          </Link>

          <div className="hidden md:flex items-center space-x-6">
            <nav className="flex items-center space-x-8" aria-label="Navigasi utama">
              <ul className="flex items-center space-x-8">
                {navItems.map((item) => (
                  <li key={item.name}>
                    <Link 
                      to={item.path} 
                      className="text-slate-600 hover:text-brand-dark font-medium transition-colors"
                    >
                      {item.name}
                    </Link>
                  </li>
                ))}
                 {isAuthenticated && (
                    <li>
                        <Link to={primaryNavItem.path} className="font-semibold text-brand-secondary hover:text-sky-400 transition-colors">
                            {primaryNavItem.name}
                        </Link>
                    </li>
                 )}
              </ul>
            </nav>

            <div className="h-6 w-px bg-slate-200"></div>
            
            <div className="flex items-center space-x-2">
              {isAuthenticated && user ? (
                 <div className="relative" ref={userMenuRef}>
                    <button onClick={() => setIsUserMenuOpen(!isUserMenuOpen)} className="flex items-center gap-2 p-2 rounded-lg hover:bg-slate-100 transition-colors">
                       <span className="h-9 w-9 rounded-full bg-brand-secondary text-white flex items-center justify-center font-bold">{user.name.charAt(0).toUpperCase()}</span>
                       <span className="font-semibold text-sm text-brand-dark hidden lg:inline">{user.name}</span>
                       <Icon className={`w-4 h-4 text-slate-500 transition-transform ${isUserMenuOpen ? 'rotate-180' : ''}`}><polyline points="6 9 12 15 18 9"></polyline></Icon>
                    </button>
                    {isUserMenuOpen && (
                        <div className="absolute right-0 mt-2 w-56 origin-top-right bg-white rounded-xl shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none animate-scaleUp">
                            <div className="py-1">
                                <div className="px-4 py-3 border-b">
                                    <p className="text-sm font-semibold text-brand-dark truncate">Signed in as</p>
                                    <p className="text-sm text-slate-500 truncate">{user.email}</p>
                                </div>
                                <a href="#" className="block px-4 py-2 text-sm text-slate-700 hover:bg-slate-100" onClick={e => {e.preventDefault(); handleLogout();}}>Logout</a>
                            </div>
                        </div>
                    )}
                 </div>
              ) : (
                <>
                  <button onClick={handleRequestCallback} className="rounded-lg text-sm font-semibold py-2.5 px-4 text-slate-700 hover:bg-slate-100 transition-colors">
                    Minta Dihubungi
                  </button>
                  <Link to="/login" className="rounded-lg text-sm font-semibold py-2.5 px-4 bg-brand-dark text-white hover:bg-slate-700 transition-colors">
                    Login/Daftar
                  </Link>
                </>
              )}
            </div>
          </div>
          
          <button
            className="md:hidden z-50"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            aria-label="Toggle menu"
            aria-expanded={isMenuOpen}
            aria-controls="mobile-menu"
          >
             <Icon className="text-brand-dark w-7 h-7">
                {isMenuOpen ? (
                   <>
                     <line x1="18" y1="6" x2="6" y2="18"></line>
                     <line x1="6" y1="6" x2="18" y2="18"></line>
                   </>
                ) : (
                   <>
                     <line x1="3" y1="12" x2="21" y2="12"></line>
                     <line x1="3" y1="6" x2="21" y2="6"></line>
                     <line x1="3" y1="18" x2="21" y2="18"></line>
                   </>
                )}
             </Icon>
          </button>
        </div>
      </div>
      
      {/* Mobile Menu */}
      <div id="mobile-menu" className={`absolute top-full left-0 w-full bg-brand-light/95 backdrop-blur-md shadow-lg md:hidden transition-all duration-300 ease-in-out overflow-hidden ${isMenuOpen ? 'max-h-screen border-t border-slate-200' : 'max-h-0'}`}>
          <nav className="px-6 pt-2 pb-6" aria-label="Navigasi mobile">
            <ul className="flex flex-col space-y-2">
              {navItems.map((item) => (
                <li key={item.name}>
                  <Link 
                    to={item.path} 
                    onClick={() => setIsMenuOpen(false)} 
                    className="block text-slate-700 hover:text-brand-dark font-semibold transition-colors py-3 text-base"
                  >
                    {item.name}
                  </Link>
                </li>
              ))}
              {isAuthenticated && (
                <li key={primaryNavItem.name}>
                    <Link
                        to={primaryNavItem.path}
                        onClick={() => setIsMenuOpen(false)}
                        className="block text-brand-secondary hover:text-sky-400 font-bold transition-colors py-3 text-base"
                    >
                        {primaryNavItem.name}
                    </Link>
                </li>
              )}
               <li>
                {isAuthenticated ? (
                  <button 
                    onClick={() => { handleLogout(); setIsMenuOpen(false); }} 
                    className="mt-4 w-full inline-flex items-center justify-center rounded-lg text-base font-semibold py-3 px-6 bg-white text-slate-700 hover:bg-slate-100 ring-1 ring-slate-200 transition-colors"
                  >
                    Logout
                  </button>
                ) : (
                  <div className="mt-4 flex flex-col gap-3">
                    <Link 
                      to="/login"
                      onClick={() => setIsMenuOpen(false)}
                      className="w-full inline-flex items-center justify-center rounded-lg text-base font-semibold py-3 px-6 bg-brand-dark text-white hover:bg-slate-700 transition-colors"
                    >
                      Login/Daftar
                    </Link>
                    <button 
                      onClick={handleRequestCallback} 
                      className="w-full inline-flex items-center justify-center rounded-lg text-base font-semibold py-3 px-6 bg-white text-slate-700 hover:bg-slate-100 ring-1 ring-slate-200 transition-colors"
                    >
                      Minta Dihubungi
                    </button>
                  </div>
                )}
              </li>
            </ul>
          </nav>
      </div>
       <style>{`
        @keyframes scaleUp {
          from { opacity: 0; transform: scale(0.95); }
          to { opacity: 1; transform: scale(1); }
        }
        .animate-scaleUp { animation: scaleUp 0.1s ease-out forwards; }
      `}</style>
    </header>
  );
};

export default Header;