import React, { useState, useEffect } from 'react';
import Icon from './Icon';
import { useAuth } from '../contexts/AuthContext';
import { User } from '../types';

interface EditProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: User;
}

const EditProfileModal: React.FC<EditProfileModalProps> = ({ isOpen, onClose, user }) => {
  const { updateUser } = useAuth();
  const [formData, setFormData] = useState({
    name: user.name || '',
    phone: user.phone || '',
  });
  const [profilePicture, setProfilePicture] = useState<string | undefined>(user.profilePicture);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    // Reset form when modal is opened or user data changes
    setFormData({
      name: user.name || '',
      phone: user.phone || '',
    });
    setProfilePicture(user.profilePicture);
  }, [isOpen, user]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };
  
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const reader = new FileReader();
      reader.onloadend = () => {
        setProfilePicture(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setError('');
    setIsSubmitting(true);
    try {
      await updateUser({
        name: formData.name,
        phone: formData.phone,
        profilePicture: profilePicture,
      });
      onClose();
    } catch (err: any) {
      setError(err.message || "Gagal memperbarui profil.");
    } finally {
      setIsSubmitting(false);
    }
  };
  
  useEffect(() => {
    const handleEsc = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleEsc);
    return () => window.removeEventListener('keydown', handleEsc);
  }, [onClose]);

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm transition-opacity duration-300 animate-fadeIn"
      aria-labelledby="modal-title"
      role="dialog"
      aria-modal="true"
      onClick={onClose}
    >
      <div
        className="relative bg-white w-full max-w-md m-4 rounded-2xl shadow-xl transform transition-all duration-300 animate-scaleUp"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="p-8">
          <h2 id="modal-title" className="text-2xl font-bold text-brand-dark mb-2">Edit Profil</h2>
          <p className="text-slate-500 mb-6">Perbarui informasi akun Anda di bawah ini.</p>
          
          {error && <div className="mb-4 text-red-600 text-sm bg-red-50 p-3 rounded-lg">{error}</div>}
          
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="flex flex-col items-center gap-4">
              <div className="h-24 w-24 rounded-full bg-slate-200 overflow-hidden flex items-center justify-center">
                 {profilePicture ? (
                    <img src={profilePicture} alt="Pratinjau Profil" className="h-full w-full object-cover" />
                  ) : (
                    <Icon className="w-12 h-12 text-slate-400"><path d="M5.52 19c.64-2.2 1.84-3 3.22-3h6.52c1.38 0 2.58.8 3.22 3" /><circle cx="12" cy="10" r="3" /><circle cx="12" cy="12" r="10" /></Icon>
                  )}
              </div>
               <label htmlFor="profilePicture" className="cursor-pointer bg-white text-brand-secondary font-semibold py-2 px-4 rounded-lg border border-brand-secondary hover:bg-sky-50 transition-colors text-sm">
                Ubah Foto
              </label>
              <input type="file" id="profilePicture" accept="image/png, image/jpeg" className="sr-only" onChange={handleFileChange} />
            </div>

            <div>
              <label htmlFor="name" className="block text-sm font-medium text-slate-700">Nama Lengkap</label>
              <input type="text" id="name" name="name" value={formData.name} onChange={handleChange} required className="mt-1 block w-full bg-slate-50 border-slate-200 rounded-lg px-4 py-2.5 text-sm focus:ring-2 focus:ring-brand-secondary focus:border-transparent" />
            </div>
            
            <div>
              <label htmlFor="phone" className="block text-sm font-medium text-slate-700">Nomor Telepon</label>
              <input type="tel" id="phone" name="phone" value={formData.phone} onChange={handleChange} className="mt-1 block w-full bg-slate-50 border-slate-200 rounded-lg px-4 py-2.5 text-sm focus:ring-2 focus:ring-brand-secondary focus:border-transparent" placeholder="+62 812..." />
            </div>
            
            <div className="pt-4 flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={onClose}
                className="bg-white text-slate-700 font-semibold py-2.5 px-6 rounded-lg ring-1 ring-slate-200 hover:bg-slate-50 transition-colors"
              >
                Batal
              </button>
              <button
                type="submit"
                disabled={isSubmitting}
                className="flex items-center justify-center bg-brand-dark text-white font-semibold py-2.5 px-6 rounded-lg transition-colors hover:bg-slate-700 disabled:bg-slate-400 disabled:cursor-not-allowed"
              >
                 {isSubmitting ? (
                  <>
                    <svg className="animate-spin -ml-1 mr-2 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    Menyimpan...
                  </>
                ) : 'Simpan Perubahan'}
              </button>
            </div>
          </form>
        </div>
      </div>
      <style>{`
        @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
        @keyframes scaleUp { from { opacity: 0; transform: scale(0.95); } to { opacity: 1; transform: scale(1); } }
        .animate-fadeIn { animation: fadeIn 0.3s ease-out forwards; }
        .animate-scaleUp { animation: scaleUp 0.3s ease-out forwards; }
      `}</style>
    </div>
  );
};

export default EditProfileModal;