import React, { createContext, useState, useContext, useEffect, ReactNode } from 'react';
import { User } from '../types';

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (email: string, pass: string) => Promise<void>;
  signup: (name: string, email: string, pass: string) => Promise<void>;
  logout: () => void;
  verifyEmail: (token: string) => Promise<void>;
  resendVerificationEmail: () => Promise<void>;
  updateUser: (updatedData: Partial<User>) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const sendVerificationEmail = (user: User) => {
  // In a real app, this would use an email service.
  // Here, we simulate by creating a token and logging it.
  const token = btoa(user.email); // Simple token for simulation
  const verificationLink = `${window.location.origin}${window.location.pathname}#/verify-email/${token}`;
  console.log('--- SIMULATED VERIFICATION EMAIL ---');
  console.log(`To: ${user.email}`);
  console.log('Please verify your email by clicking the link below:');
  console.log(verificationLink);
  console.log('------------------------------------');
};


export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Simulate checking for an existing session in localStorage
    try {
      const storedUser = localStorage.getItem('halloHukumUser');
      if (storedUser) {
        setUser(JSON.parse(storedUser));
      }
    } catch (error) {
      console.error("Failed to parse user from localStorage", error);
      localStorage.removeItem('halloHukumUser');
    } finally {
      setIsLoading(false);
    }
  }, []);

  const login = async (email: string, pass: string): Promise<void> => {
    setIsLoading(true);
    // Simulate API call
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        // In a real app, you'd verify credentials. Here we check localStorage.
        const storedUser = localStorage.getItem('halloHukumUser');
        if (storedUser) {
            const parsedUser: User = JSON.parse(storedUser);
            if (parsedUser.email === email) { // Simple check
                setUser(parsedUser);
                resolve();
            } else {
                 reject(new Error('Invalid credentials'));
            }
        } else {
            reject(new Error('User not found. Please sign up.'));
        }
        setIsLoading(false);
      }, 1000);
    });
  };

  const signup = async (name: string, email: string, pass: string): Promise<void> => {
    setIsLoading(true);
    // Simulate API call
    return new Promise((resolve) => {
      setTimeout(() => {
        const newUser: User = { id: Date.now().toString(), name, email, isEmailVerified: false };
        localStorage.setItem('halloHukumUser', JSON.stringify(newUser));
        setUser(newUser);
        sendVerificationEmail(newUser);
        setIsLoading(false);
        resolve();
      }, 1000);
    });
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('halloHukumUser');
  };
  
  const verifyEmail = async (token: string): Promise<void> => {
     return new Promise((resolve, reject) => {
        setTimeout(() => {
            try {
                const email = atob(token);
                const storedUser = localStorage.getItem('halloHukumUser');
                if (storedUser) {
                    const parsedUser: User = JSON.parse(storedUser);
                    if (parsedUser.email === email) {
                        const updatedUser = { ...parsedUser, isEmailVerified: true };
                        localStorage.setItem('halloHukumUser', JSON.stringify(updatedUser));
                        setUser(updatedUser);
                        resolve();
                    } else {
                        reject(new Error("Token does not match stored user."));
                    }
                } else {
                    reject(new Error("No user found in storage."));
                }
            } catch (e) {
                reject(new Error("Invalid verification token."));
            }
        }, 1500);
     });
  };
  
  const resendVerificationEmail = async (): Promise<void> => {
      return new Promise((resolve, reject) => {
          if (user && !user.isEmailVerified) {
              sendVerificationEmail(user);
              resolve();
          } else if (user?.isEmailVerified) {
              reject(new Error("Email is already verified."));
          } else {
              reject(new Error("No user is logged in to resend verification for."));
          }
      });
  };

  const updateUser = async (updatedData: Partial<User>): Promise<void> => {
    return new Promise((resolve, reject) => {
        if (user) {
            const newUser = { ...user, ...updatedData };
            setUser(newUser);
            localStorage.setItem('halloHukumUser', JSON.stringify(newUser));
            resolve();
        } else {
            reject(new Error("No user is logged in to update."));
        }
    });
  };

  const value = {
    user,
    isAuthenticated: !!user,
    isLoading,
    login,
    signup,
    logout,
    verifyEmail,
    resendVerificationEmail,
    updateUser,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};